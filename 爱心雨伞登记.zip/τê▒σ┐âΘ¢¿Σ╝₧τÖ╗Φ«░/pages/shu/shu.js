// pages/shu/shu.js
Page({
  //借书按钮关闭函数a1
  guana1(){
    //获取时间
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
      new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
      new Date().getSeconds()
      dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
    this.setData({
      kaiqi1:true
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("yonghuxinxi").where({
      _openid:openId
    }).get().then(ress => {  
      const db = wx.cloud.database().collection("A1")
      db.add({
        data:{
          shuju:ress.data,
          time:dataTime,
          bianhao:"C1"
        }})})}})
      },
  // 借书按钮开启函数
  kai1(){
    this.setData({
      kaiqi1:false
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("A1").where({
      _openid:openId
    }).remove({})
  }})},


    //借书按钮关闭函数a2
    guana2(){
      //获取时间
      let dataTime
      let yy = new Date().getFullYear()
      let mm = new Date().getMonth()+1
      let dd = new Date().getDate()
      let hh = new Date().getHours()
      let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
        new Date().getMinutes()
      let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
        new Date().getSeconds()
        dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
      this.setData({
        kaiqi2:true
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("yonghuxinxi").where({
        _openid:openId
      }).get().then(ress => {  
        const db = wx.cloud.database().collection("A2")
        db.add({
          data:{
            shuju:ress.data,
            time:dataTime,
            bianhao:"C2"
          }})})}})
        },
    // 借书按钮开启函数
    kai2(){
      this.setData({
        kaiqi2:false
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("A2").where({
        _openid:openId
      }).remove({})
    }})},
  
  //借书按钮关闭函数a3
  guana3(){
    //获取时间
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
      new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
      new Date().getSeconds()
      dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
    this.setData({
      kaiqi3:true
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("yonghuxinxi").where({
      _openid:openId
    }).get().then(ress => {  
      const db = wx.cloud.database().collection("A3")
      db.add({
        data:{
          shuju:ress.data,
          time:dataTime,
          bianhao:"C3"
        }})})}})
      },
  // 借书按钮开启函数
  kai3(){
    this.setData({
      kaiqi3:false
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("A3").where({
      _openid:openId
    }).remove({})
  }})},

  //借书按钮关闭函数a4
  guana4(){
    //获取时间
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
      new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
      new Date().getSeconds()
      dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
    this.setData({
      kaiqi4:true
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("yonghuxinxi").where({
      _openid:openId
    }).get().then(ress => {  
      const db = wx.cloud.database().collection("A4")
      db.add({
        data:{
          shuju:ress.data,
          time:dataTime,
          bianhao:"C4"
        }})})}})
      },
  // 借书按钮开启函数
  kai4(){
    this.setData({
      kaiqi4:false
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("A4").where({
      _openid:openId
    }).remove({})
  }})},

  //借书按钮关闭函数a5
  guana5(){
    //获取时间
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
      new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
      new Date().getSeconds()
      dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
    this.setData({
      kaiqi5:true
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("yonghuxinxi").where({
      _openid:openId
    }).get().then(ress => {  
      const db = wx.cloud.database().collection("A5")
      db.add({
        data:{
          shuju:ress.data,
          time:dataTime,
          bianhao:"C5"
        }})})}})
      },
  // 借书按钮开启函数
  kai5(){
    this.setData({
      kaiqi5:false
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("A5").where({
      _openid:openId
    }).remove({})
  }})},

    //借书按钮关闭函数a6
    guana6(){
      //获取时间
      let dataTime
      let yy = new Date().getFullYear()
      let mm = new Date().getMonth()+1
      let dd = new Date().getDate()
      let hh = new Date().getHours()
      let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
        new Date().getMinutes()
      let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
        new Date().getSeconds()
        dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
      this.setData({
        kaiqi6:true
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("yonghuxinxi").where({
        _openid:openId
      }).get().then(ress => {  
        const db = wx.cloud.database().collection("A6")
        db.add({
          data:{
            shuju:ress.data,
            time:dataTime,
            bianhao:"C6"
          }})})}})
        },
    // 借书按钮开启函数
    kai6(){
      this.setData({
        kaiqi6:false
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("A6").where({
        _openid:openId
      }).remove({})
    }})},

      //借书按钮关闭函数a7
  guana7(){
    //获取时间
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
      new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
      new Date().getSeconds()
      dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
    this.setData({
      kaiqi7:true
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("yonghuxinxi").where({
      _openid:openId
    }).get().then(ress => {  
      const db = wx.cloud.database().collection("A7")
      db.add({
        data:{
          shuju:ress.data,
          time:dataTime,
          bianhao:"C7"
        }})})}})
      },
  // 借书按钮开启函数
  kai7(){
    this.setData({
      kaiqi7:false
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("A7").where({
      _openid:openId
    }).remove({})
  }})},

    //借书按钮关闭函数a8
    guana8(){
      //获取时间
      let dataTime
      let yy = new Date().getFullYear()
      let mm = new Date().getMonth()+1
      let dd = new Date().getDate()
      let hh = new Date().getHours()
      let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
        new Date().getMinutes()
      let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
        new Date().getSeconds()
        dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
      this.setData({
        kaiqi8:true
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("yonghuxinxi").where({
        _openid:openId
      }).get().then(ress => {  
        const db = wx.cloud.database().collection("A8")
        db.add({
          data:{
            shuju:ress.data,
            time:dataTime,
            bianhao:"C8"
          }})})}})
        },
    // 借书按钮开启函数
    kai8(){
      this.setData({
        kaiqi8:false
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("A8").where({
        _openid:openId
      }).remove({})
    }})},

      //借书按钮关闭函数a9
  guana9(){
    //获取时间
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
      new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
      new Date().getSeconds()
      dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
    this.setData({
      kaiqi9:true
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("yonghuxinxi").where({
      _openid:openId
    }).get().then(ress => {  
      const db = wx.cloud.database().collection("A9")
      db.add({
        data:{
          shuju:ress.data,
          time:dataTime,
          bianhao:"C9"
        }})})}})
      },
  // 借书按钮开启函数
  kai9(){
    this.setData({
      kaiqi9:false
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("A9").where({
      _openid:openId
    }).remove({})
  }})},

    //借书按钮关闭函数a10
    guana10(){
      //获取时间
      let dataTime
      let yy = new Date().getFullYear()
      let mm = new Date().getMonth()+1
      let dd = new Date().getDate()
      let hh = new Date().getHours()
      let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
        new Date().getMinutes()
      let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
        new Date().getSeconds()
        dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
      this.setData({
        kaiqi10:true
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("yonghuxinxi").where({
        _openid:openId
      }).get().then(ress => {  
        const db = wx.cloud.database().collection("A10")
        db.add({
          data:{
            shuju:ress.data,
            time:dataTime,
            bianhao:"C10"
          }})})}})
        },
    // 借书按钮开启函数
    kai10(){
      this.setData({
        kaiqi10:false
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("A10").where({
        _openid:openId
      }).remove({})
    }})},

      //借书按钮关闭函数a11
  guana11(){
    //获取时间
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
      new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
      new Date().getSeconds()
      dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
    this.setData({
      kaiqi11:true
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("yonghuxinxi").where({
      _openid:openId
    }).get().then(ress => {  
      const db = wx.cloud.database().collection("A11")
      db.add({
        data:{
          shuju:ress.data,
          time:dataTime,
          bianhao:"C11"
        }})})}})
      },
  // 借书按钮开启函数
  kai11(){
    this.setData({
      kaiqi11:false
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("A11").where({
      _openid:openId
    }).remove({})
  }})},

    //借书按钮关闭函数a12
    guana12(){
      //获取时间
      let dataTime
      let yy = new Date().getFullYear()
      let mm = new Date().getMonth()+1
      let dd = new Date().getDate()
      let hh = new Date().getHours()
      let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
        new Date().getMinutes()
      let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
        new Date().getSeconds()
        dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
      this.setData({
        kaiqi12:true
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("yonghuxinxi").where({
        _openid:openId
      }).get().then(ress => {  
        const db = wx.cloud.database().collection("A12")
        db.add({
          data:{
            shuju:ress.data,
            time:dataTime,
            bianhao:"C12"
          }})})}})
        },
    // 借书按钮开启函数
    kai12(){
      this.setData({
        kaiqi12:false
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("A12").where({
        _openid:openId
      }).remove({})
    }})},

      //借书按钮关闭函数a13
  guana13(){
    //获取时间
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
      new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
      new Date().getSeconds()
      dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
    this.setData({
      kaiqi13:true
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("yonghuxinxi").where({
      _openid:openId
    }).get().then(ress => {  
      const db = wx.cloud.database().collection("A13")
      db.add({
        data:{
          shuju:ress.data,
          time:dataTime,
          bianhao:"C13"
        }})})}})
      },
  // 借书按钮开启函数
  kai13(){
    this.setData({
      kaiqi13:false
    })
    // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("A13").where({
      _openid:openId
    }).remove({})
  }})},

    //借书按钮关闭函数a14
    guana14(){
      //获取时间
      let dataTime
      let yy = new Date().getFullYear()
      let mm = new Date().getMonth()+1
      let dd = new Date().getDate()
      let hh = new Date().getHours()
      let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
        new Date().getMinutes()
      let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
        new Date().getSeconds()
        dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`; 
      this.setData({
        kaiqi14:true
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("yonghuxinxi").where({
        _openid:openId
      }).get().then(ress => {  
        const db = wx.cloud.database().collection("A14")
        db.add({
          data:{
            shuju:ress.data,
            time:dataTime,
            bianhao:"C14"
          }})})}})
        },
    // 借书按钮开启函数
    kai14(){
      this.setData({
        kaiqi14:false
      })
      // login云函数查询用户授权登陆的appid,openid
     wx.cloud.callFunction({
      name: "getOpenid",
      success(res){
      // 授权用户的openid
      let openId= res.result.openid
      // 判断openid是否存在于数据库
      wx.cloud.database().collection("A14").where({
        _openid:openId
      }).remove({})
    }})},
  
  data: {
    kaiqi1:false,
    kaiqi2:false,
    kaiqi3:false,
    kaiqi4:false,
    kaiqi5:false,
    kaiqi6:false,
    kaiqi7:false,
    kaiqi8:false,
    kaiqi9:false,
    kaiqi10:false,
    kaiqi11:false,
    kaiqi12:false,
    kaiqi13:false,
    kaiqi14:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
})