// app.js
App({
  onLaunch:function(){
    console.log('小程序开始启动')
    //云开发初始化
    wx.cloud.init({
      env:'cloud1-6g5n7d3da0d9860e',
      traceUser: true,
    })


   // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("yonghuxinxi").where({
      _openid:openId
    }).get().then(ress => {
      if(ress.data.length==0){
        wx.navigateTo({
          url: '/pages/per/per'
        })
      }else{
        wx.navigateTo({
          url: '/pages/jiesan/jiesan',
        })
      }
    })
    },fail(res){
      console.log("云函数调用失败")
    }
  })    


  }
})
