
const db = wx.cloud.database().collection("yonghuxinxi") //数据库存放用户信息
Page({
  //保存数据
  save(){
    var that=this; 
    db.add({
  data:{
    userNAME:that.data.NAME ,//姓名
    userPHONE:that.data.PHONE, //手机号
    userBANJI:that.data.BANJI, //班级
  }
})
wx.navigateTo({

  url: '/pages/jiesan/jiesan',

  })
  },
  //姓名事件
  name(e){
    var that =this
    that.setData({
      NAME:e.detail.value
    })
  },

  //手机号事件
  phone(e){
    var that =this
    that.setData({
      PHONE:e.detail.value
    })
  },

  //班级事件
  banji(e){
    var that =this
    that.setData({
      BANJI:e.detail.value
    })}
})
