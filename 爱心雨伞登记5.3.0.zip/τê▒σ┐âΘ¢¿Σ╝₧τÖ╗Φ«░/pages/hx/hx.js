// pages/hx/hx.js

Page({

  //播放音乐函数
  player(audio){
    var that =this
    audio.title = '等着我回来'
    audio.epname = '等着我回来'
    audio.singer = '戴羽彤'
    audio.src = 'https://636c-cloud1-6g5n7d3da0d9860e-1313177812.tcb.qcloud.la/%E7%AD%89%E7%9D%80%E6%88%91%E5%9B%9E%E6%9D%A5.mp3?sign=c3b65e9252589384a3db1befce321441&t=1671174703'

    audio.onEnded(()=>{
      that.player(wx.getBackgroundAudioManager())
    })


  },

  //跳转2023过年界面
  Click1(){
    wx.navigateTo({
      url: '/pages/onlyone/onlyone',
    })
  },

  //控制文字显示
  Textshow(){
    //控制公主殿下驾到
    if (this.data.Control==1) {
      this.setData({
        Text:"欢迎公主殿下",
        Image1:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/皇冠.jpeg",
        Hidden:true,
        Text1:"让我们回顾在青协的一年",
        Image2:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/猫咪.jpg",
        Text2:"第一次素拓",
        Image3:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/歌唱.jpg",
        Image4:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/合照1.jpg",
        Text3:"一起唱歌,一起玩游戏,超级开心🥰\n相遇就是缘分,感谢我们的相遇 😍",
        Image5:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/太阳.jpg",
        Image6:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/气球.jpg",
        Text4:"团建",
        Image7:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/合照2.jpg",
        Text5:"\n阳光正暖，不负时光.\n一路向前，未来可期！",
        Text6:"😄",
        Image8:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/圣诞礼物.jpg",
        Text7:"圣诞礼物来咯",
        Image9:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/合照3.jpg",
        Image10:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/小猫.jpg",
        Text8:"飘雪的冬季有了你们不再感到寒冷",
        Image11:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/小兔子发.jpg",
        Text9:"点击下方 小兔子\n一起迎接2023年"

      })
    }
  },

  //按钮点击时间
  Click(){
    this.setData({
      Control:this.data.Control+1
    })
    console.log(this.data.Control)
    this.Textshow()
  },


  /**
   * 页面的初始数据
   */
  data: {
    Text:"",
    Text1:"",
    Control:0,
    Image1:"cloud://cloud1-6g5n7d3da0d9860e.636c-cloud1-6g5n7d3da0d9860e-1313177812/星星.jpg",
    Hidden:false,
    Image2:"",
    Text2:"",
    Image3:"",
    Image4:"",
    Text3:"",
    Image5:"",
    Image6:"",
    Text4:"",
    Image7:"",
    Text5:"",
    Text6:"",
    Image8:"",
    Image9:"",
    Image10:"",
    Text8:"",
    Image11:"",
    Text9:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.player(wx.getBackgroundAudioManager())

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.Textshow()
    this.player(wx.getBackgroundAudioManager())

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})