// pages/qx/xz/xz2023/xz2023.js
Page({

  //播放音乐函数
  player(audio){
    var that =this
    audio.title = '等着我回来'
    audio.epname = '等着我回来'
    audio.singer = '戴羽彤'
    audio.src = 'https://636c-cloud1-6g5n7d3da0d9860e-1313177812.tcb.qcloud.la/%E7%AD%89%E7%9D%80%E6%88%91%E5%9B%9E%E6%9D%A5.mp3?sign=c3b65e9252589384a3db1befce321441&t=1671174703'

    audio.onEnded(()=>{
      that.player(wx.getBackgroundAudioManager())
    })


  },

  Click(){
    wx.navigateTo({
      url: '/pages/onlyone/onlyone',
    })
  },

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.player(wx.getBackgroundAudioManager())

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.player(wx.getBackgroundAudioManager())

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})