// pages/jiesan/jiesan.js
Page({

//跳转到立德楼页面
  touch1:function(param){
    wx.navigateTo({
      url: '/pages/xilidelou/xilidelou',
      })
  },

//跳转到一食堂页面
  touch2:function(param){
    wx.navigateTo({
  
      url: '/pages/xyishitang/xyishitang',
  
      })
  },

//跳转到二食堂页面
  touch3:function(param){
    wx.navigateTo({
  
      url: '/pages/xershitang/xershitang',
  
      })
  },
  
  touch4:function(){

    this.setData({

      guanbi:true
    })
    
    wx.showToast({
      title: '还伞成功',
      icon: 'success',
      duration: 2000 //持续的时间
    })

      // login云函数查询用户授权登陆的appid,openid
   wx.cloud.callFunction({
    name: "getOpenid",
    success(res){
    // 授权用户的openid
    let openId= res.result.openid
    // 判断openid是否存在于数据库
    wx.cloud.database().collection("xlidelou").where({
      _openid:openId
    }).remove({})

    wx.cloud.database().collection("xshitang1").where({
      _openid:openId
    }).remove({})

    wx.cloud.database().collection("xshitang2").where({
      _openid:openId
    }).remove({})
  }})

  },
  
  


  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})